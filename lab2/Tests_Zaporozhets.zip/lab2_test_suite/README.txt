Тестовый набор для защиты Lab 2 — Никончук Андрей Андреевич, 11Б

Ожидается:
valid.jpg  -> OK, 320x240, 300x300 dpi
valid.png  -> OK, 320x240
valid.gif  -> OK, 320x240
valid.tif  -> OK, 320x240, LZW, IFD
valid8.bmp -> OK, 320x240, 8 bit
valid.pcx  -> OK, 320x240, 24 bit, RLE
broken.jpg -> Файл поврежден (нет FF D9)
broken.png -> Файл поврежден (нет IEND)
fake.jpg   -> Файл поврежден (подмена расширения)
